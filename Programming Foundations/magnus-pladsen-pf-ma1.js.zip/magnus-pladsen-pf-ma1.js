// question 1
const name = "Magnus Pladsen";
let age = 25;
let alive = true;

// question 2
const firstName = "Magnus";
const lastName = "Pladsen";
const fullName = firstName + " " + lastName;
console.log(fullName);

// question 3
const frogType = typeof "Frog";
console.log(`The type of frog is ${frogType}`);

// question 4
let orderHasShipped = false;
if (orderHasShipped === true) {
  console.log("The order shipped");
} else {
  console.log("The order did not ship");
}

// question 5
for (let i = 7; i <= 13; i++) {
  console.log(i);
}
